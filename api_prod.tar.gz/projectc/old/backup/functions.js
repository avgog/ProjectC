const exec = (query, res) => {
    db.query(query, function(err,resp){
      if(!err) { console.log("Query [ " + query + " ] succeded!"); res.send(resp); }
      else { console.log(err); res.send("Error!"); }
    });
};
  
// NOTE: Make sure the user in the unsafe.json has plugin 'mysql_native_password', otherwise it will crash.
var db = mysql.createConnection({
    host: app_settings.db.host,
    user: app_settings.db.user,
    password: app_settings.db.pass,
    database: app_settings.db.database
});

// TIME //

module.exports.add_time = async function(route_id, end_time, callbackObject){
    let query = `insert into times(route_id, end_time) values (${route_id}, '${end_time}')`
    database.executeQuery(query, callbackObject)
}

module.exports.get_time = async function(id, callbackObject){
    let query = `select id, route_id, DATE_FORMAT(end_time, '%Y-%m-%d %T') as end_time from times where id = ${id}`
    database.executeQuery(query, callbackObject)
}

module.exports.get_route_times = async function(route_id, callbackObject){
    let query = `select id, route_id, DATE_FORMAT(end_time, '%Y-%m-%d %T') as end_time from times where route_id = ${route_id}`
    database.executeQuery(query, callbackObject)
}

//end_time [datetime] format: 'YYYY-MM-DD hh:mm:ss'
module.exports.change_time = async function(id, end_time, callbackObject){
    let query = `update times set end_time = '${end_time}' where id = ${id}`
    database.executeQuery(query, callbackObject)
}

module.exports.remove_time = async function(id, callbackObject){
    let query = `delete from times where id = ${id}`
    database.executeQuery(query, callbackObject)
}


// ROUTE //

module.exports.add_route = async function(user_id, start_point, end_point, name, callbackObject=null){
    const query = `
    insert into routes 
    (user_id, start_point, end_point, route_name) 
    VALUES (`+user_id+`,'`+start_point+`','`+end_point+`','`+name+`');`;
    database.executeQuery(query, callbackObject);
}

module.exports.get_route = async function(route_id, callbackObject=null){
    const query = `select * from routes where route_id = ` + route_id;
    database.executeQuery(query, callbackObject);
}

module.exports.get_user_routes = async function(user_id, callbackObject=null){
    const query = `select * from routes where user_id = ` + user_id;
    database.executeQuery(query, callbackObject);
}

module.exports.change_start_point = async function(route_id, start_point, callbackObject=null){
    const query = `update routes set start_point = '` + start_point + `' where route_id = '` + route_id + `'`;
    database.executeQuery(query, callbackObject);
    
}

module.exports.change_end_point = async function(route_id, end_point, callbackObject=null){
    const query = `update routes set end_point = '` + end_point + `' where route_id = '` + route_id + `'`;
    database.executeQuery(query, callbackObject);
    
}

module.exports.change_route_name = async function(route_id, route_name, callbackObject=null){
    const query = `update routes set route_name = '` + route_name + `' where route_id = '` + route_id + `'`;
    database.executeQuery(query, callbackObject);
}

module.exports.remove_route = async function(route_id, callbackObject=null){
    const query = `delete from routes where route_id = ` + route_id+ ``;
    database.executeQuery(query, callbackObject);
}


