// NODEJS MODULES //
const express = require('express');
const fs = require('fs');
const bodyparser = require('body-parser');
const mysql = require('mysql');

// IMPORTING FILES //
//const funct = require(__dirname + "/functions.js");
const app_settings = JSON.parse( fs.readFileSync(__dirname + "/settings/unsafe.json") );

// SETTING UP EXPRESS SERVER //
var app = express();
  app.use(bodyparser.json());
  app.use(bodyparser.urlencoded({ extended: false }));

// FUNCTIONS //
const exec = (query, res) => {
    db.query(query, function(err,resp){
      if(!err) { console.log("Query [ " + query + " ] succeded!"); res.send(resp); }
      else { console.log(err); res.send("Error!"); }
    });
};
  
// NOTE: Make sure the user in the unsafe.json has plugin 'mysql_native_password', otherwise it will crash.
var db = mysql.createConnection({
    host: app_settings.db.host,
    user: app_settings.db.user,
    password: app_settings.db.pass,
    database: app_settings.db.database
});

// INTERNAL USE ONLY //
app.post('/query', function(req, res) {
  let data = req.body;
  let query = data.query;
    
  console.log(Object.keys(data));
  console.log(query);
  
  exec(query,res);
});

// USED IN OVNOTIFIER SERVICE //
app.get('/routes', function(req, res) {
  let data = req.body;
  let route = data.route
  let query = "SELECT * FROM Routes WHERE route_id = '" + route + "';";
  exec(query,res);
});

app.get('/times', function(req, res) {
  let query = "SELECT * FROM Times;";
  exec(query,res);
});

app.get('/time', function(req, res) {
  let data = req.body;
  let time_id = data.id;
  let query = "SELECT * FROM Times WHERE id='" + time_id + "';";
  exec(query,res);
});

app.get('/stops', function(req, res) {
  let data = req.body;
  let stop = data.stop;
  let town = data.town;
  let query = "SELECT * FROM Stops WHERE name = '" + stop + "' AND town = '" + town + "';";
  exec(query,res);
});

app.post('/starttime', function(req, res) {
  let data = req.body;
  let id = data.id;
  let time = data.time;
  let query = "UPDATE Times SET timeofstart = '" + time + "' WHERE id = '" + id + "';";
  exec(query,res);
});


// PUBLIC ACCESSABLE //
app.get('/public/route', function(req, res) {
  let data = req.body;
  let from = data.from;
  let to = data.to;
  let date = data.date;
  let time = data.time;
  let type = data.type; /* normal / full / int */
});



// START NODEJS SERVER //
app.listen(666, function () {
  console.log('Ready...');
});

